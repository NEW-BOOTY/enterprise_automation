# GoBazelForge Pitch

1. Title: GoBazel Innovation  
2. Problem: Bazel silos.  
3. Solution: Polyglot.  
4. Why Google: Go/TF.  
5. Ask: License.