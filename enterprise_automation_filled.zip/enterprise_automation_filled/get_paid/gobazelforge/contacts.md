# Google Outreach

- **Dev Relations**: Google DevRel LinkedIn[](https://www.linkedin.com/posts/google_googles-developer-relations-team-collaborates-activity-7333566344207994880-4jp3); Jobs .
- **Partnerships**: Google LinkedIn .
- **Innovation Labs**: AI for Good .
- **CTO**: Search LinkedIn/Google execs.
- **LinkedIn/AngelList**: , .

# Google Outreach

- DevRel: developers.google.com  
- Partnerships: cloud.google.com/partners  
- CTO: Google exec LinkedIn  