# OpenAI Outreach

- DevRel: platform.openai.com  
- Partnerships: openai.com/partners  
- CTO: OpenAI exec LinkedIn  