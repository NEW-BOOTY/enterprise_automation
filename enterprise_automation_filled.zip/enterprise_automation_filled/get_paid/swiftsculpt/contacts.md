# Apple Outreach

- DevRel: developer.apple.com  
- Partnerships: Apple Enterprise  
- CTO: Apple exec LinkedIn  