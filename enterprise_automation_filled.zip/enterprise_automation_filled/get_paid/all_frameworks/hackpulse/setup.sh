#!/bin/bash
set -euo pipefail
LOG_DIR="logs"; mkdir -p "$LOG_DIR"
LOG_FILE="$LOG_DIR/setup_$(date +%Y%m%d_%H%M%S).log"
touch "$LOG_FILE"; chmod 600 "$LOG_FILE"
exec 1>> "$LOG_FILE" 2>&1

echo "Installing: hhvm"
brew update || true
brew install --quiet hhvm || true

PROJ="generated"
mkdir -p "$PROJ/src" "$PROJ/db" "$PROJ/terraform" "$PROJ/systemd"
cat > "$PROJ/src/index.hack" << 'HACK'
<?hh // strict
/*
 * Copyright © 2025 Devin B. Royal.
 * All Rights Reserved.
 */
<<__EntryPoint>>
function main(): void { echo "Hello HackPulse on HHVM\n"; }
HACK
echo "Generated in $PROJ"
