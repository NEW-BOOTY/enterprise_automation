#!/bin/bash
set -euo pipefail
LOG_DIR="logs"; mkdir -p "$LOG_DIR"
LOG_FILE="$LOG_DIR/setup_$(date +%Y%m%d_%H%M%S).log"
touch "$LOG_FILE"; chmod 600 "$LOG_FILE"
exec 1>> "$LOG_FILE" 2>&1

echo "Installing: rust"
brew update || true
brew install --quiet rust || true

PROJ="generated"
mkdir -p "$PROJ/src" "$PROJ/db" "$PROJ/terraform" "$PROJ/systemd"
mkdir -p "$PROJ/src"
cat > "$PROJ/src/Cargo.toml" << 'TOML'
[package]
name = "lambdaloom"
version = "0.1.0"
edition = "2021"

[[bin]]
name = "handler"
path = "src/main.rs"
TOML
cat > "$PROJ/src/main.rs" << 'RUST'
/*
 * Copyright © 2025 Devin B. Royal.
 * All Rights Reserved.
 */
fn main() {
    println!("Hello LambdaLoom");
}
RUST
echo "Generated in $PROJ"
