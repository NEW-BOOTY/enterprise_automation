#!/bin/bash
set -euo pipefail
LOG_DIR="logs"; mkdir -p "$LOG_DIR"
LOG_FILE="$LOG_DIR/setup_$(date +%Y%m%d_%H%M%S).log"
touch "$LOG_FILE"; chmod 600 "$LOG_FILE"
exec 1>> "$LOG_FILE" 2>&1

echo "Installing: dotnet@8"
brew update || true
brew install --quiet dotnet@8 || true

PROJ="generated"
mkdir -p "$PROJ/src" "$PROJ/db" "$PROJ/terraform" "$PROJ/systemd"
mkdir -p "$PROJ/src"
cat > "$PROJ/src/HelloAzure.csproj" << 'CS'
<Project Sdk="Microsoft.NET.Sdk">
  <PropertyGroup><OutputType>Exe</OutputType><TargetFramework>net8.0</TargetFramework></PropertyGroup>
</Project>
CS
cat > "$PROJ/src/Program.cs" << 'CS'
/*
 * Copyright © 2025 Devin B. Royal.
 * All Rights Reserved.
 */
Console.WriteLine("Hello AzureWeave");
CS
echo "Generated in $PROJ"
