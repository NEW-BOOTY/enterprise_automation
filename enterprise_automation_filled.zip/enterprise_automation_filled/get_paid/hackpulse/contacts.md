# Meta Outreach

- DevRel: developers.facebook.com  
- Partnerships: Meta open source  
- CTO: Andrew Bosworth LinkedIn  