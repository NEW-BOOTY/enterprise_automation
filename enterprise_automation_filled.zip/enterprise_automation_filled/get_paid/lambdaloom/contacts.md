# Amazon Outreach

- DevRel: aws.amazon.com/developer  
- Partnerships: aws.amazon.com/partners  
- CTO: Amazon exec LinkedIn  