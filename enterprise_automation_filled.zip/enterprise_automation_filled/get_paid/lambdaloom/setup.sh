#!/bin/bash
#
# Copyright © 2025 Devin B. Royal.
# All Rights Reserved.
#

set -euo pipefail

validate_env() {
    if [[ "$(uname -s)" != "Darwin" ]]; then echo "ERROR: macOS." >&2; exit 1; fi
    if ! command -v brew &> /dev/null; then NONINTERACTIVE=1 /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)" || exit 1; fi
}

LOG_DIR="logs"
mkdir -p "${LOG_DIR}"
LOG_FILE="${LOG_DIR}/setup_$(date +%Y%m%d_%H%M%S).log"
touch "${LOG_FILE}"
chmod 600 "${LOG_FILE}"
exec 1> >(tee -a "${LOG_FILE}")
exec 2>&1
trap 'echo "FATAL ${LINENO}" | tee -a "${LOG_FILE}"; cleanup' ERR
cleanup() { find "${LOG_DIR}" -name "*.tmp" -delete; exit 1; }

install_deps() {
    brew update || exit 1
    brew install --quiet awscli rust node python java terraform ansible go || true
    aws --version &> /dev/null || exit 1
    cargo --version &> /dev/null || exit 1
}

generate_project() {
    PROJ_DIR="generated"
    mkdir -p "${PROJ_DIR}/src" "${PROJ_DIR}/db" "${PROJ_DIR}/terraform" "${PROJ_DIR}/systemd"

    cat > "${PROJ_DIR}/src/handler.rs" << 'EOF'
/*
 * Copyright © 2025 Devin B. Royal.
 * All Rights Reserved.
 */
use lambda_runtime::{handler_fn, Context};
type Error = Box<dyn std::error::Error>;
#[tokio::main]
async fn main() -> Result<(), Error> { lambda_runtime::run(handler_fn(func)).await?; Ok(()) }
async fn func(_: (), _: Context) -> Result<(), Error> { println!("LambdaLoom Rust"); Ok(()) }
EOF

    cat > "${PROJ_DIR}/src/index.js" << 'EOF'
// Copyright © 2025 Devin B. Royal. All Rights Reserved.
exports.handler = async () => { console.log("JS Lambda"); };
EOF

    cat > "${PROJ_DIR}/db/schema.ddl" << 'EOF'
-- Copyright © 2025 Devin B. Royal. All Rights Reserved.
CREATE TABLE loom (id INT);
EOF

    cat > "${PROJ_DIR}/Dockerfile" << 'EOF'
# Copyright © 2025 Devin B. Royal. All Rights Reserved.
FROM rust:1.75
COPY src/ /app/
RUN cargo build --release --bin handler
CMD ["/app/target/release/handler"]
EOF

    cat > "${PROJ_DIR}/ecs-task.json" << 'EOF'
# Copyright © 2025 Devin B. Royal. All Rights Reserved.
{ "family": "lambdaloom", "containerDefinitions": [{ "name": "app", "image": "lambdaloom:latest" }] }
EOF

    cat > "${PROJ_DIR}/Makefile" << 'EOF'
# Copyright © 2025 Devin B. Royal. All Rights Reserved.
build: cargo build --release
deploy: aws lambda update-function-code --function-name loom --zip-file fileb://target/release/bootstrap.zip
EOF

    cat > "${PROJ_DIR}/ansible-playbook.yaml" << 'EOF'
# Copyright © 2025 Devin B. Royal. All Rights Reserved.
---
- hosts: localhost
  tasks: [command: aws ecs register-task-definition --cli-input-json file://ecs-task.json]
EOF

    cat > "${PROJ_DIR}/terraform/main.tf" << 'EOF'
# Copyright © 2025 Devin B. Royal. All Rights Reserved.
provider "aws" {}
resource "aws_lambda_function" "loom" { function_name = "lambdaloom" }
EOF

    cat > "${PROJ_DIR}/cron-job.conf" << 'EOF'
# Copyright © 2025 Devin B. Royal. All Rights Reserved.
*/15 * * * * aws lambda invoke --function-name loom output.json
EOF

    cat > "${PROJ_DIR}/systemd/lambdaloom.service" << 'EOF'
# Copyright © 2025 Devin B. Royal. All Rights Reserved.
[Unit]
Description=LambdaLoom
[Service]
ExecStart=/app/target/release/handler
Restart=always
[Install]
WantedBy=multi-user.target
EOF

    cat > "${PROJ_DIR}/cicd-pipeline.yaml" << 'EOF'
# Copyright © 2025 Devin B. Royal. All Rights Reserved.
stages: [build: make build, deploy: aws deploy]
EOF

    echo "Generated in ${PROJ_DIR}" >&2
}

main() { validate_env; install_deps; generate_project; echo "LambdaLoom deployed. Logs: ${LOG_FILE}" >&2; }

main "$@"
#
# Copyright © 2025 Devin B. Royal.
# All Rights Reserved.
#