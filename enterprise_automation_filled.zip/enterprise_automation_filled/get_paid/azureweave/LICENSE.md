# Enterprise License for AzureWeave

Copyright © 2025 Devin B. Royal. All Rights Reserved.

Perpetual license to Microsoft for internal use. Negotiable fees. No redistribution. CA law.