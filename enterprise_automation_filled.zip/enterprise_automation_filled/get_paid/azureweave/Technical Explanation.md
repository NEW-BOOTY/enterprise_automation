Technical Explanation
AzureWeave mirrors OracleForge: Strict Bash with traps, installs .NET/PowerShell/Docker, generates C# app (compiles to exe), Azure YAML for CI, Terraform azurerm. Interactions: Makefile builds, cron runs PS scripts. Choices: .NET for MS alignment; secure exec. Features: Polyglot stubs. Error: Pipefail + logging. Security: Chmod, no env leaks.
(ZIP: azureweave.zip)