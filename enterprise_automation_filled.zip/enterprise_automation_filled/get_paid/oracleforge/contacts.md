# Oracle Outreach Points

- **Developer Relations**: Oracle Developers LinkedIn[](https://www.linkedin.com/showcase/oracledevs/) – Community for devs.
- **Partnerships**: Oracle PartnerNetwork[](https://www.oracle.com/partner/) – Accelerate business.
- **Innovation Labs**: Index Ventures contributors[](https://www.indexventures.com/winning-in-the-us/key-contributors) – US partnerships focus.
- **CTO/Leadership**: Search LinkedIn for Oracle CTO (e.g., via[](https://www.linkedin.com/company/oracle)).
- **LinkedIn/AngelList/Portals**: Oracle LinkedIn ; AngelList partnerships  (general VC); Official: partner.oracle.com.