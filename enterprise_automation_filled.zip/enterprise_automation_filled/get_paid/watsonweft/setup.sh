#!/bin/bash
#
# Copyright © 2025 Devin B. Royal.
# All Rights Reserved.
#

set -euo pipefail

validate_env() {
    if [[ "$(uname -s)" != "Darwin" ]]; then echo "ERROR: macOS." >&2; exit 1; fi
    if ! command -v brew &> /dev/null; then NONINTERACTIVE=1 /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)" || exit 1; fi
}

LOG_DIR="logs"
mkdir -p "${LOG_DIR}"
LOG_FILE="${LOG_DIR}/setup_$(date +%Y%m%d_%H%M%S).log"
touch "${LOG_FILE}"
chmod 600 "${LOG_FILE}"
exec 1> >(tee -a "${LOG_FILE}")
exec 2>&1
trap 'echo "FATAL ${LINENO}" | tee -a "${LOG_FILE}"; cleanup' ERR
cleanup() { find "${LOG_DIR}" -name "*.tmp" -delete; exit 1; }

install_deps() {
    brew update || exit 1
    brew install --quiet openjdk python node cobol terraform ansible rust go || true
    java --version &> /dev/null || exit 1
}

generate_project() {
    PROJ_DIR="generated"
    mkdir -p "${PROJ_DIR}/src" "${PROJ_DIR}/ai" "${PROJ_DIR}/terraform" "${PROJ_DIR}/systemd"

    cat > "${PROJ_DIR}/src/HelloWatson.java" << 'EOF'
/*
 * Copyright © 2025 Devin B. Royal.
 * All Rights Reserved.
 */
public class HelloWatson { public static void main(String[] args) { System.out.println("Hello WatsonWeft"); } }
EOF

    cat > "${PROJ_DIR}/src/hello.cbl" << 'EOF'
       IDENTIFICATION DIVISION.
       PROGRAM-ID. HELLO-WATSON.
       PROCEDURE DIVISION.
           DISPLAY 'Hello from COBOL in WatsonWeft'.
           STOP RUN.
EOF

    cat > "${PROJ_DIR}/ai/watson-call.py" << 'EOF'
# Copyright © 2025 Devin B. Royal. All Rights Reserved.
print("Watson AI call stub")
EOF

    cat > "${PROJ_DIR}/Dockerfile" << 'EOF'
# Copyright © 2025 Devin B. Royal. All Rights Reserved.
FROM openjdk:17
COPY src/ /app/
RUN javac /app/HelloWatson.java
CMD ["java", "-cp", "/app", "HelloWatson"]
EOF

    cat > "${PROJ_DIR}/openshift-route.yaml" << 'EOF'
# Copyright © 2025 Devin B. Royal. All Rights Reserved.
kind: Route
metadata: { name: watsonweft }
spec: { to: { kind: Service, name: app } }
EOF

    cat > "${PROJ_DIR}/Makefile" << 'EOF'
# Copyright © 2025 Devin B. Royal. All Rights Reserved.
build: docker build -t watsonweft .
deploy: oc apply -f openshift-route.yaml
EOF

    cat > "${PROJ_DIR}/ansible-playbook.yaml" << 'EOF'
# Copyright © 2025 Devin B. Royal. All Rights Reserved.
---
- hosts: localhost
  tasks: [command: oc apply -f openshift-route.yaml]
EOF

    cat > "${PROJ_DIR}/terraform/main.tf" << 'EOF'
# Copyright © 2025 Devin B. Royal. All Rights Reserved.
provider "openshift" {}
resource "openshift_project" "weft" { name = "watsonweft" }
EOF

    cat > "${PROJ_DIR}/cron-job.conf" << 'EOF'
# Copyright © 2025 Devin B. Royal. All Rights Reserved.
0 */2 * * * java -cp /app HelloWatson >> /var/log/watsonweft.log 2>&1
EOF

    cat > "${PROJ_DIR}/systemd/watsonweft.service" << 'EOF'
# Copyright © 2025 Devin B. Royal. All Rights Reserved.
[Unit]
Description=WatsonWeft
[Service]
ExecStart=/usr/bin/java -cp /app HelloWatson
Restart=always
[Install]
WantedBy=multi-user.target
EOF

    cat > "${PROJ_DIR}/cicd-pipeline.yaml" << 'EOF'
# Copyright © 2025 Devin B. Royal. All Rights Reserved.
stages: [build: make build, deploy: oc apply]
EOF

    echo "Generated in ${PROJ_DIR}" >&2
}

main() { validate_env; install_deps; generate_project; echo "WatsonWeft deployed. Logs: ${LOG_FILE}" >&2; }

main "$@"
#
# Copyright © 2025 Devin B. Royal.
# All Rights Reserved.
#